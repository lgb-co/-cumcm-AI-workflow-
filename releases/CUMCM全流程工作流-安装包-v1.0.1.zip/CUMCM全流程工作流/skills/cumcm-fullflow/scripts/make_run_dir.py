#!/usr/bin/env python3
"""建立（或重置）一次数模全流程运行目录。

用法:
    python make_run_dir.py "D:\\工作区\\运行\\2026A-药材的烘干问题"
    python make_run_dir.py "<运行目录>" --reset      # 旧目录整体移入 _回收站

--reset 不会删除任何文件：旧运行目录被移动到 <工作区>\\_回收站\\<名称>_<时间戳>，
便于需要时回看或恢复。
"""

from __future__ import annotations

import argparse
import shutil
import sys
from datetime import datetime
from pathlib import Path

SUBDIRS = [
    "00_题目",
    "01_建模方案",
    "02_方案评审",
    "03_代码",
    "04_代码检测",
    "05_论文",
    "交付",
]

LOG_NAME = "00_流程日志.md"
LOG_HEADER = (
    "# 流程日志\n\n"
    "> 由 cumcm-fullflow 维护：每阶段结束追加一行，重跑时先看本文件判断上游产物能否复用。\n\n"
    "| 时间 | 阶段 | 产物路径 | 结论 | 未决项 |\n"
    "|---|---|---|---|---|\n"
)


def trash_root(run_dir: Path) -> Path:
    """运行目录通常是 <工作区>/运行/<项目>，回收站放在 <工作区>/_回收站。"""
    if run_dir.parent.name == "运行":
        return run_dir.parent.parent / "_回收站"
    return run_dir.parent / "_回收站"


def reset(run_dir: Path) -> Path | None:
    if not run_dir.exists():
        return None
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    target = trash_root(run_dir) / f"{run_dir.name}_{stamp}"
    if target.exists():
        print(f"ABORT: 回收站目标已存在 {target}", file=sys.stderr)
        raise SystemExit(1)
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(run_dir), str(target))
    print(f"MOVED  {run_dir}  ->  {target}")
    return target


def main() -> int:
    ap = argparse.ArgumentParser(description="建立或重置数模全流程运行目录")
    ap.add_argument("run_dir", help="运行目录，例如 <工作区>\\运行\\2026A-药材的烘干问题")
    ap.add_argument("--reset", action="store_true", help="把已存在的运行目录整体移入 _回收站 后重建")
    args = ap.parse_args()

    run_dir = Path(args.run_dir).expanduser().resolve()
    if args.reset:
        reset(run_dir)
    elif run_dir.exists():
        print(f"NOTE: 目录已存在，保留原内容，只补齐缺失骨架: {run_dir}")

    for name in SUBDIRS:
        (run_dir / name).mkdir(parents=True, exist_ok=True)

    log = run_dir / LOG_NAME
    if not log.exists():
        log.write_text(LOG_HEADER, encoding="utf-8")

    print(f"RUN_DIR {run_dir}")
    for name in SUBDIRS:
        print(f"  - {name}")
    print(f"  - {LOG_NAME}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
