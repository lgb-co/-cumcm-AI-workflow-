"""校验阶段回执：产物是否存在、哈希是否一致、上游是否被篡改、必填字段是否齐全。

用法：
    python verify_receipt.py --manifest _handoff/S4_manifest.json --receipt _handoff/S4_receipt.json --base <运行目录>
退出码 0 = 通过；1 = 不通过（原因打印在标准输出）。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

# Windows 控制台默认 GBK，回执里的 −、≈ 等字符会导致打印崩溃
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # pragma: no cover
    pass

REQUIRED = ("stage", "status", "artifacts", "unresolved")
NEED_REPRO = {"S2", "S4", "S4B", "S4R", "S5c"}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser(description="校验阶段回执")
    ap.add_argument("--manifest", required=True)
    ap.add_argument("--receipt", required=True)
    ap.add_argument("--base", required=True)
    args = ap.parse_args()

    base = Path(args.base).resolve()
    manifest = json.loads(Path(args.manifest).read_text(encoding="utf-8"))
    receipt = json.loads(Path(args.receipt).read_text(encoding="utf-8"))
    problems: list[str] = []
    notes: list[str] = []

    if receipt.get("stage") != manifest.get("stage"):
        problems.append(f"阶段不一致：清单 {manifest.get('stage')} vs 回执 {receipt.get('stage')}")
    for key in REQUIRED:
        if key not in receipt:
            problems.append(f"回执缺少字段：{key}")
    if receipt.get("stage") in NEED_REPRO and not receipt.get("reproduction"):
        problems.append("该阶段必须提供 reproduction（复跑命令与独立复算值）")
    if receipt.get("stage") in {"S2", "S2R", "S4", "S4B", "S4R", "S5c"}:
        rr = receipt.get("inputs_reread") or {}
        if rr.get("problem_text") is not True:
            problems.append("inputs_reread.problem_text 必须为 true（须重读赛题原文）")
        if rr.get("question_card_rebuilt") is not True:
            problems.append("inputs_reread.question_card_rebuilt 必须为 true（须自行重建逐问要求）")
        need = [Path(e["path"]).name for e in manifest.get("entries", [])
                if e["path"].startswith("00_题目/") and not e["path"].lower().endswith(".txt")]
        # 回执里可能写文件名、相对路径，或带括号注释（如 “附件1-烘房温湿度.xlsx（241 行…）”），统一取文件名并去掉注释
        def _attach_key(x) -> str:
            # 允许两种写法：纯字符串，或 {file/path/name, sha256, check, result} 对象
            if isinstance(x, dict):
                x = x.get("file") or x.get("path") or x.get("name") or ""
            name = Path(str(x).split("（")[0].split("(")[0].strip()).name
            return name.strip()

        got = {_attach_key(x) for x in (rr.get("attachments_verified") or [])}
        missing = [n for n in need if n not in got]
        if missing:
            problems.append("inputs_reread.attachments_verified 未覆盖附件：" + "、".join(missing))
        vals = rr.get("recomputed_values") or []
        if len(vals) < 3:
            problems.append("inputs_reread.recomputed_values 至少 3 条（须独立复算关键量）")
    if receipt.get("stage") == "S4R":
        mc = receipt.get("model_change")
        if not isinstance(mc, dict):
            problems.append("S4R 必须提供 model_change（模型复盘结论）")
        else:
            for k in ("changed", "requires_rerun"):
                if not isinstance(mc.get(k), bool):
                    problems.append(f"model_change.{k} 必须为布尔值")
            if mc.get("changed") and not mc.get("changes"):
                problems.append("model_change.changed=true 时必须列出 changes（优化清单）")
    # 逐问复读与四遍分析：protocol_version ≥ 1.2 的回执强制，S4R 一律强制
    pv = str(receipt.get("protocol_version") or "")
    strict13 = bool(pv) and pv >= "1.3"
    if strict13 and receipt.get("stage") == "S1":
        sc = receipt.get("self_check")
        if not isinstance(sc, dict):
            problems.append("S1 缺少 self_check（交付前严格自检表）")
        else:
            for k in ("formula_implementable", "acceptance_criteria", "dimension_check",
                      "assumptions_with_evidence", "requirement_mapping", "data_traceable"):
                if sc.get(k) is not True:
                    problems.append(f"self_check.{k} 必须为 true")
            risks = sc.get("risk_list") or []
            if len(risks) < 3:
                problems.append("self_check.risk_list 至少 3 条风险与验证计划")
    if strict13 and receipt.get("stage") in ("S2", "S2R"):
        sr = receipt.get("strict_review")
        if not isinstance(sr, dict):
            problems.append("S2 缺少 strict_review（更严评审结论）")
        else:
            rc = sr.get("requirement_coverage") or {}
            if not isinstance(rc, dict) or not isinstance(rc.get("missing"), int):
                problems.append("strict_review.requirement_coverage.missing 必须为整数")
            elif rc["missing"] != 0 and sr.get("verdict") != "需返工":
                problems.append("requirement_coverage.missing>0 时 verdict 必须为「需返工」")
            if len(sr.get("counter_checks") or []) < 1:
                problems.append("strict_review.counter_checks 至少 1 条（反驳性检查）")
            if len(sr.get("evidence_table") or []) < 3:
                problems.append("strict_review.evidence_table 至少 3 条")
            if sr.get("verdict") not in ("通过", "有条件通过", "需返工"):
                problems.append("strict_review.verdict 必须是 通过/有条件通过/需返工")
    need_pqr = receipt.get("stage") in ("S4R",) or (pv and pv >= "1.2")
    if need_pqr:
        pqr = receipt.get("per_question_reread")
        if not isinstance(pqr, list) or not pqr:
            problems.append("缺少 per_question_reread（逐问复读与四遍分析记录）")
        else:
            for item in pqr:
                if not isinstance(item, dict):
                    problems.append("per_question_reread 条目必须是对象")
                    continue
                q = item.get("question") or "?"
                if not item.get("source_quotes"):
                    problems.append(f"per_question_reread[{q}] 缺少 source_quotes（原文摘录与页码）")
                rounds = item.get("rounds")
                if not isinstance(rounds, int) or rounds < 3:
                    problems.append(f"per_question_reread[{q}] 轮次不足 3（抄读/自解/对照/反查）")
        pre = receipt.get("preread")
        if not isinstance(pre, dict):
            problems.append("缺少 preread（无技能预读会话产物：抄读 + 自解）")
        else:
            if pre.get("no_skill") is not True:
                problems.append("preread.no_skill 必须为 true（①② 必须在无技能会话完成）")
            ap = pre.get("artifact")
            if not ap:
                problems.append("preread.artifact 缺失（应为 _handoff/<阶段>_preread.md）")
            else:
                fp = base / ap
                if not fp.is_file():
                    problems.append(f"preread 产物缺失：{ap}")
                elif pre.get("sha256") and sha256(fp) != pre["sha256"]:
                    problems.append(f"preread 产物哈希不符：{ap}")
    if receipt.get("stage") == "S5c":
        rt = receipt.get("requirement_trace") or {}
        if not rt.get("file"):
            problems.append("S5c 必须提供 requirement_trace.file（赛题要求对照表）")
        for k in ("total", "satisfied", "partial", "missing"):
            if not isinstance(rt.get(k), int):
                problems.append(f"requirement_trace.{k} 必须为整数")
        if isinstance(rt.get("missing"), int) and rt["missing"] != 0:
            problems.append(f"赛题要求对照仍有 {rt['missing']} 条未满足，不得交付")
        if not receipt.get("independent_trace_review"):
            problems.append("S5c 必须提供 independent_trace_review（独立复核报告路径）")
    status = receipt.get("status") or ""
    if not (status == "完成" or status.startswith("完成")):
        problems.append(f"阶段状态为「{status}」，不得进入下一阶段")

    for art in receipt.get("artifacts", []) or []:
        p = base / art.get("path", "")
        if not p.is_file():
            problems.append(f"产物缺失：{art.get('path')}")
            continue
        if art.get("sha256") and sha256(p) != art["sha256"]:
            problems.append(f"产物哈希与回执不符：{art.get('path')}")
    if not receipt.get("artifacts"):
        problems.append("回执未登记任何产物")

    for entry in manifest.get("entries", []):
        p = base / entry["path"]
        # role=lead 的条目是"线索"性质（如持续追加的流程日志），缺失或变化只提示，不阻断
        if entry.get("role") == "lead":
            if not p.is_file():
                notes.append(f"线索文件缺失（不阻断）：{entry['path']}")
            elif sha256(p) != entry["sha256"]:
                notes.append(f"线索文件已更新（不阻断）：{entry['path']}")
            continue
        if not p.is_file():
            problems.append(f"上游输入缺失：{entry['path']}")
        elif sha256(p) != entry["sha256"]:
            problems.append(f"上游输入被改动：{entry['path']}")

    if problems:
        print("[回执校验] 不通过：")
        for x in problems:
            print("  -", x)
        for x in notes:
            print("  ·", x)
        return 1
    print(f"[回执校验] 通过：阶段 {receipt['stage']}，产物 {len(receipt['artifacts'])} 个，"
          f"上游输入 {len(manifest.get('entries', []))} 个未改动")
    for x in notes:
        print("  ·", x)
    if receipt.get("reproduction"):
        rep = receipt["reproduction"]
        if isinstance(rep, dict):
            cmds = rep.get("commands") or []
            print(f"  复跑命令：{'; '.join(str(c) for c in cmds)}（{rep.get('seconds', '?')} s）")
            vals = rep.get("values") or []
            if isinstance(vals, dict):
                vals = [{"name": k, "value": v} for k, v in vals.items()]
            for v in vals[:5]:
                if isinstance(v, dict):
                    print(f"  独立复算 {v.get('name')} = {v.get('value')}（{v.get('source', '')}）")
                else:
                    print(f"  独立复算 {v}")
        else:
            print(f"  复跑记录：{rep}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
