"""生成阶段密封交接清单（逐文件 SHA-256），供子代理作为唯一输入依据。

用法：
    python build_handoff.py --stage S4 --run-dir "<运行目录>" [--extra 相对路径 …]
输出：<运行目录>/_handoff/<阶段>_manifest.json
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path

# 每阶段的输入规格：glob 模式 + 角色（evidence / lead）
SPEC: dict[str, list[tuple[str, str]]] = {
    "S1": [("00_题目/**", "evidence"), ("_handoff/S1_preread.md", "evidence")],
    "S2": [("00_题目/**", "evidence"), ("01_建模方案/**", "evidence"),
           ("_handoff/S2_preread.md", "evidence"), ("00_流程日志.md", "lead")],
    "S2R": [("00_题目/**", "evidence"), ("01_建模方案/**", "evidence"),
            ("_handoff/S2R_preread.md", "evidence"), ("00_流程日志.md", "lead")],
    "S3": [("00_题目/**", "evidence"), ("01_建模方案/**", "evidence")],
    "S4": [("00_题目/**", "evidence"), ("01_建模方案/**", "evidence"),
           ("03_代码/output/**", "evidence"), ("03_代码/work/**", "lead")],
    "S4B": [("00_题目/**", "evidence"), ("01_建模方案/**", "evidence"),
            ("03_代码/output/**", "evidence"), ("03_代码/work/**", "lead")],
    "S4R": [("00_题目/**", "evidence"), ("01_建模方案/**", "evidence"),
            ("_handoff/S4R_preread.md", "evidence"),
            ("03_代码/output/**", "evidence"), ("04_代码检测/**", "evidence"),
            ("03_代码/work/**", "lead")],
    "S5a": [("00_题目/**", "evidence"), ("01_建模方案/**", "evidence"),
            ("03_代码/output/**/results/**", "evidence"),
            ("03_代码/output/**/tables/**", "evidence"),
            ("03_代码/output/**/figures/**", "evidence"),
            ("03_代码/work/**", "lead")],
    "S5b": [("05_论文/论文正文.md", "evidence")],
    "S5c": [("05_论文/**", "evidence"), ("00_题目/**", "evidence"),
            ("03_代码/output/**/tables/**", "evidence")],
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser(description="生成阶段密封交接清单")
    ap.add_argument("--stage", required=True, choices=sorted(SPEC))
    ap.add_argument("--run-dir", required=True)
    ap.add_argument("--extra", nargs="*", default=[])
    ap.add_argument("--out")
    args = ap.parse_args()

    run = Path(args.run_dir).resolve()
    entries, seen = [], set()
    # 噪声目录不进清单：字节码缓存、修订过程的代码备份/临时目录（避免把旧代码当输入）
    EXCLUDE_PARTS = ("__pycache__", "备份_", "_stage", ".ipynb_checkpoints")
    # 阶段自身的产物目录要排除（例如 S5c 不应把 05_论文 的旧版当成输入之外的东西）
    for pattern, role in SPEC[args.stage] + [(p, "evidence") for p in args.extra]:
        # pathlib 的 "dir/**" 只匹配目录本身，须改为 "dir/**/*" 才能取到文件
        pat = pattern[:-3] + "/**/*" if pattern.endswith("/**") else pattern
        for path in sorted(run.glob(pat)):
            if not path.is_file():
                continue
            rel = path.relative_to(run).as_posix()
            if any(part in rel for part in EXCLUDE_PARTS):
                continue
            if rel in seen or rel.startswith("_handoff/"):
                continue
            seen.add(rel)
            entries.append({"path": rel, "role": role, "bytes": path.stat().st_size,
                            "sha256": sha256(path)})
    manifest = {"stage": args.stage, "run_dir": str(run),
                "created": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "entries": entries, "total_bytes": sum(e["bytes"] for e in entries)}
    out = Path(args.out) if args.out else run / "_handoff" / f"{args.stage}_manifest.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"[交接清单] {args.stage}：{len(entries)} 个文件，{manifest['total_bytes'] / 1024:.0f} KB → {out}")
    for e in entries[:5]:
        print(f"  - {e['path'][:60]} ({e['role']})")
    if len(entries) > 5:
        print(f"  … 其余 {len(entries) - 5} 个文件")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
