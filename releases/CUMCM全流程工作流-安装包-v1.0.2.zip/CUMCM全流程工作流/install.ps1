﻿<#
.SYNOPSIS
    CUMCM 全流程工作流安装脚本（安装 / 校验 / 卸载）。

.DESCRIPTION
    安装 6 个技能到 <目标>\（默认 %USERPROFILE%\.codex\skills），并把查看版 DOCX 导出工具
    装到 <目标>\工具\，同时探测本机 Python 写入环境配置（不再携带打包者的机器路径）。

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\install.ps1
    powershell -ExecutionPolicy Bypass -File .\install.ps1 -Action Check
    powershell -ExecutionPolicy Bypass -File .\install.ps1 -Action Uninstall
    powershell -ExecutionPolicy Bypass -File .\install.ps1 -Destination "D:\my\skills" -SetupTools
#>
[CmdletBinding()]
param(
    [ValidateSet('Install','Check','Uninstall')][string]$Action = 'Install',
    [string]$Destination = $(if (Test-Path (Join-Path $env:USERPROFILE '.codex\skills')) { Join-Path $env:USERPROFILE '.codex\skills' } else { Join-Path $env:USERPROFILE '.agents\skills' }),
    [switch]$SetupTools
)
$ErrorActionPreference = 'Stop'
try { [Console]::OutputEncoding = [Text.UTF8Encoding]::new($false) } catch { }
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$srcSkills = Join-Path $here 'skills'
$srcTools = Join-Path $here 'tools'
$base = [IO.Path]::GetFullPath($Destination)
$volumeRoot = [IO.Path]::GetPathRoot($base)
if ([string]::Equals($base.TrimEnd('\'), $volumeRoot.TrimEnd('\'), [StringComparison]::OrdinalIgnoreCase)) {
    throw ('拒绝把磁盘根目录作为安装目标：' + $base)
}
$packageRoot = [IO.Path]::GetFullPath($here).TrimEnd('\')
if ($base.StartsWith($packageRoot + '\', [StringComparison]::OrdinalIgnoreCase) -or
    [string]::Equals($base.TrimEnd('\'), $packageRoot, [StringComparison]::OrdinalIgnoreCase)) {
    throw ('安装目标不能位于安装包目录内：' + $base)
}
$toolsDst = Join-Path $base '工具'
$manifestName = '_workflow_tools.manifest.json'
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$parent = [IO.Directory]::GetParent($base)
if (-not $parent) { throw ('安装目标无安全父目录：' + $base) }
$backup = Join-Path $parent.FullName ('.cumcm-workflow-backups\' + $stamp)
if (-not (Test-Path -LiteralPath $srcSkills -PathType Container)) { throw ('安装包缺少 skills 目录：' + $srcSkills) }
$names = @(Get-ChildItem -LiteralPath $srcSkills -Directory | Where-Object { $_.Name -notmatch '^(__|\.)' } | Select-Object -ExpandProperty Name)
if ($names.Count -eq 0) { throw ('安装包没有可安装的技能目录：' + $srcSkills) }
foreach ($n in $names) {
    $skillPath = Join-Path (Join-Path $srcSkills $n) 'SKILL.md'
    if (-not (Test-Path -LiteralPath $skillPath -PathType Leaf)) { throw ('技能目录缺少 SKILL.md：' + $n) }
}
$toolFiles = @()
if (Test-Path -LiteralPath $srcTools) { $toolFiles = @(Get-ChildItem -LiteralPath $srcTools -File | Select-Object -ExpandProperty Name) }
function Get-Sha256([string]$path) {
    $sha = [Security.Cryptography.SHA256]::Create()
    $stream = [IO.File]::OpenRead($path)
    try { return [BitConverter]::ToString($sha.ComputeHash($stream)).Replace('-', '') }
    finally { $stream.Dispose(); $sha.Dispose() }
}
$packageMetadata = Join-Path $here 'BUILD_METADATA.json'
if (Test-Path -LiteralPath $packageMetadata) {
    try {
        $meta = Get-Content -LiteralPath $packageMetadata -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($meta.version -ne '1.0.2') { throw ('安装包版本元数据不匹配：' + $meta.version) }
        $declared = @($meta.skills | ForEach-Object { [string]$_.name })
        if ($declared.Count -ne $names.Count -or @($names | Where-Object { $_ -notin $declared }).Count -gt 0) {
            throw '安装包技能目录与 BUILD_METADATA.json 不一致'
        }
        foreach ($entry in @($meta.skills)) {
            $sourceSkill = Join-Path (Join-Path $srcSkills ([string]$entry.name)) 'SKILL.md'
            $actualHash = Get-Sha256 $sourceSkill
            if (-not [string]::Equals($actualHash, [string]$entry.skill_sha256, [StringComparison]::OrdinalIgnoreCase)) {
                throw ('安装包 SKILL.md 哈希不符：' + $entry.name)
            }
        }
    } catch { throw ('安装包 BUILD_METADATA.json 无效：' + $_.Exception.Message) }
}

function Find-Python {
    $cands = New-Object System.Collections.ArrayList
    foreach ($v in @($env:CUMCM_CODE_ENV, $env:CUMCM_PYTHON, $env:MODELING_PY)) { if ($v) { [void]$cands.Add($v) } }
    [void]$cands.Add((Join-Path $toolsDst 'md2docx_env\Scripts\python.exe'))
    foreach ($n in @('python.exe','python3.exe','python','python3')) {
        $cmd = Get-Command $n -ErrorAction SilentlyContinue
        if ($cmd -and $cmd.Source -notmatch 'WindowsApps') { [void]$cands.Add($cmd.Source) }
    }
    $runtime = Join-Path $env:USERPROFILE '.cache\codex-runtimes'
    if (Test-Path -LiteralPath $runtime) {
        $found = Get-ChildItem -LiteralPath $runtime -Filter python.exe -Recurse -ErrorAction SilentlyContinue |
            Where-Object { $_.FullName -match 'dependencies[\\/]python[\\/]python\.exe$' } | Select-Object -First 1
        if ($found) { [void]$cands.Add($found.FullName) }
    }
    foreach ($c in $cands) {
        if (-not $c) { continue }
        $p = $c
        if (Test-Path -LiteralPath $p -PathType Container) {
            $q = Join-Path $p 'Scripts\python.exe'
            if (-not (Test-Path -LiteralPath $q)) { $q = Join-Path $p 'python.exe' }
            $p = $q
        }
        if (Test-Path -LiteralPath $p) { return $p }
    }
    return $null
}

function Write-EnvConfigs([string]$python) {
    $stampText = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    if ($python) {
        $codeCfg = [ordered]@{
            skill          = 'cumcm-code-writer'
            installed_at   = $stampText
            source_package = $script:packageLabel
            code_env       = $python
            note           = '安装时探测写入；换机器请改这里或设置环境变量 CUMCM_CODE_ENV'
        }
        $codeCfgPath = Join-Path $base 'cumcm-code-writer\环境配置.json'
        if (Test-Path -LiteralPath (Split-Path -Parent $codeCfgPath)) {
            ($codeCfg | ConvertTo-Json -Depth 3) | Set-Content -LiteralPath $codeCfgPath -Encoding UTF8
        }
        $toolCfgPath = Join-Path $toolsDst '环境配置.json'
        if (Test-Path -LiteralPath $toolCfgPath) {
            try {
                $obj = Get-Content -LiteralPath $toolCfgPath -Raw -Encoding UTF8 | ConvertFrom-Json
                if (-not $obj.python) { $obj | Add-Member -NotePropertyName python -NotePropertyValue $python -Force }
                $obj | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath $toolCfgPath -Encoding UTF8
            } catch {
                # 配置文件损坏时写一个最小、可诊断的替代配置；旧实现引用了
                # 未定义的 $cfg，导致二次异常并掩盖真正原因。
                $cfgBackupDir = Join-Path $backup '工具'
                New-Item -ItemType Directory -Force -Path $cfgBackupDir | Out-Null
                $cfgBackup = Join-Path $cfgBackupDir ('环境配置.invalid-' + [guid]::NewGuid().ToString('N') + '.json')
                Move-Item -LiteralPath $toolCfgPath -Destination $cfgBackup
                $fallback = [ordered]@{
                    python         = $python
                    detected_at    = $stampText
                    source_package = $script:packageLabel
                    note           = '原环境配置无法解析，已备份后由安装程序重建；可手工补充其它字段。'
                }
                ($fallback | ConvertTo-Json -Depth 3) | Set-Content -LiteralPath $toolCfgPath -Encoding UTF8
                Write-Warning ('无效环境配置已备份到：' + $cfgBackup)
            }
        } else {
            $toolCfg = [ordered]@{
                python         = $python
                detected_at    = $stampText
                source_package = $script:packageLabel
                note           = '供 数学模型建立/论文导出 等技能使用；可用 MODELING_PY / CUMCM_PYTHON 覆盖；原生公式导出依赖见 setup-md2docx.ps1'
            }
            ($toolCfg | ConvertTo-Json -Depth 3) | Set-Content -LiteralPath $toolCfgPath -Encoding UTF8
        }
    }
}

if ($Action -eq 'Check') {
    $bad = 0
    foreach ($n in $names) {
        $t = Join-Path $base $n
        $ok = Test-Path (Join-Path $t 'SKILL.md')
        if (-not $ok) { $bad++ }
        Write-Output ("{0}  {1}" -f ($(if ($ok) { 'OK ' } else { '缺失' }), $n))
    }
    foreach ($f in @('md2docx_native.py','md2docx_latex.py','setup-md2docx.ps1','requirements-tools.txt')) {
        $ok = Test-Path -LiteralPath (Join-Path $toolsDst $f)
        if (-not $ok) { $bad++ }
        Write-Output ("{0}  工具\{1}" -f ($(if ($ok) { 'OK ' } else { '缺失' }), $f))
    }
    $py = Find-Python
    if ($py) {
        Write-Output ('Python：' + $py)
        $pandoc = ''
        try { $pandoc = (& $py -c "import pypandoc;print(pypandoc.get_pandoc_path())" 2>$null) } catch { $pandoc = '' }
        if ($pandoc) { Write-Output ('原生公式导出依赖：OK（pandoc ' + ([string]$pandoc).Trim() + '）') }
        else { Write-Output '原生公式导出依赖：未就绪，需要时运行 工具\setup-md2docx.ps1（首次需联网）' }
    } else {
        Write-Output 'Python：未找到（写码/计算/导出需要 Python 3.11+，可设置 CUMCM_PYTHON 指定）'
    }
    if ($bad -gt 0) { throw ("有 $bad 项未安装完整") } else { Write-Output '校验通过：技能与工具链均已就位' }
    return
}

if ($Action -eq 'Uninstall') {
    New-Item -ItemType Directory -Force -Path (Join-Path $backup '工具') | Out-Null
    $manifest = Join-Path $toolsDst $manifestName
    if (Test-Path -LiteralPath $manifest) {
        $files = @((Get-Content -LiteralPath $manifest -Raw -Encoding UTF8 | ConvertFrom-Json).files)
        foreach ($f in $files) {
            $t = Join-Path $toolsDst $f
            if (Test-Path -LiteralPath $t) { Move-Item -LiteralPath $t -Destination (Join-Path $backup ('工具\' + $f)) }
        }
        Move-Item -LiteralPath $manifest -Destination (Join-Path $backup ('工具\' + $manifestName))
        Write-Output ('已卸载工具链文件（备份在 ' + (Join-Path $backup '工具') + '）')
    }
    foreach ($n in $names) {
        $t = Join-Path $base $n
        if (Test-Path -LiteralPath $t) { Move-Item -LiteralPath $t -Destination (Join-Path $backup $n) }
    }
    Write-Output ('已卸载，备份在 ' + $backup)
    return
}

$script:packageLabel = 'CUMCM全流程工作流 v1.0.2'
New-Item -ItemType Directory -Force -Path $base, $backup | Out-Null
foreach ($n in $names) {
    $s = Join-Path $srcSkills $n
    $t = Join-Path $base $n
    if (Test-Path -LiteralPath $t) { Move-Item -LiteralPath $t -Destination (Join-Path $backup $n); Write-Output ('已备份旧版: ' + $n) }
    Copy-Item -LiteralPath $s -Destination $t -Recurse
    if (-not (Test-Path (Join-Path $t 'SKILL.md'))) { throw ('安装失败（缺 SKILL.md）: ' + $n) }
    Write-Output ('已安装: ' + $n)
}
if ($toolFiles.Count -gt 0) {
    New-Item -ItemType Directory -Force -Path $toolsDst | Out-Null
    foreach ($f in $toolFiles) {
        $t = Join-Path $toolsDst $f
        if (Test-Path -LiteralPath $t) { Move-Item -LiteralPath $t -Destination (Join-Path $backup ('工具\' + $f)) }
        Copy-Item -LiteralPath (Join-Path $srcTools $f) -Destination $t -Force
    }
    $manifestPath = Join-Path $toolsDst $manifestName
    ([ordered]@{ source_package = $script:packageLabel; installed_at = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'); files = $toolFiles } | ConvertTo-Json -Depth 3) |
        Set-Content -LiteralPath $manifestPath -Encoding UTF8
    Write-Output ('已安装工具链 ' + $toolFiles.Count + ' 个文件 → ' + $toolsDst)
}
$pythonFound = Find-Python
Write-EnvConfigs $pythonFound
if ($pythonFound) { Write-Output ('已写入环境配置，Python：' + $pythonFound) }
else { Write-Warning '未在本机找到 Python：写码/计算与 DOCX 导出都不可用，请装 Python 3.11+ 或设置 CUMCM_PYTHON 后重跑本脚本。' }
if ($SetupTools) {
    $setup = Join-Path $toolsDst 'setup-md2docx.ps1'
    if (Test-Path -LiteralPath $setup) { & $setup -Python $pythonFound } else { Write-Warning ('未找到 ' + $setup) }
}
Write-Output ('完成，共 ' + $names.Count + ' 个技能 → ' + $base)
Write-Output '在 Codex 新任务里输入「用 $cumcm-fullflow 跑 <某年某题>」即可启动全流程。'
$setupPath = Join-Path $toolsDst 'setup-md2docx.ps1'
Write-Output ('若需要「查看版 DOCX（Word 原生公式）」，先运行：powershell -ExecutionPolicy Bypass -File "' + $setupPath + '"')
