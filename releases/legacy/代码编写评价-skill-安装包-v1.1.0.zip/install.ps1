﻿[CmdletBinding()]
param(
 [ValidateSet('Install','Check','Uninstall')][string]$Action='Install',
 [string]$Destination=$(if(Test-Path (Join-Path $env:USERPROFILE '.codex\skills')){Join-Path $env:USERPROFILE '.codex\skills'}else{Join-Path $env:USERPROFILE '.agents\skills'})
)
$ErrorActionPreference='Stop'
$skillFolder='cumcm-code-reviewer'
$source=Join-Path $PSScriptRoot $skillFolder
$base=[IO.Path]::GetFullPath($Destination)
$target=[IO.Path]::GetFullPath((Join-Path $base $skillFolder))
$backupBase=Join-Path ([IO.Directory]::GetParent($base).FullName) '.cumcm-code-reviewer-backups'
function Get-Sha([string]$p){ $s=[IO.File]::OpenRead($p); $h=[Security.Cryptography.SHA256]::Create(); try{ ([BitConverter]::ToString($h.ComputeHash($s))).Replace('-','').ToLower() } finally { $s.Dispose(); $h.Dispose() } }
function Verify-Manifest([string]$Folder){
  $m=Join-Path $Folder 'manifest.json'
  if(!(Test-Path -LiteralPath $m)){ throw 'manifest.json 缺失' }
  $j=Get-Content -LiteralPath $m -Raw -Encoding UTF8 | ConvertFrom-Json
  foreach($f in $j.files){
    $p=Join-Path $Folder ($f.path -replace '/','\')
    if(!(Test-Path -LiteralPath $p)){ throw ('缺少文件: '+$f.path) }
    if((Get-Sha $p) -ne $f.sha256.ToLower()){ throw ('校验和不符: '+$f.path) }
  }
  return $j
}
if($Action -eq 'Check'){ $j=Verify-Manifest $target; Write-Output ('校验通过: '+$target+'  version '+$j.version); return }
if($Action -eq 'Uninstall'){
  if(Test-Path -LiteralPath $target){
    New-Item -ItemType Directory -Force -Path $backupBase | Out-Null
    $dst=Join-Path $backupBase ($skillFolder+'-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
    Move-Item -LiteralPath $target -Destination $dst
    Write-Output ('已卸载，备份保留在 '+$dst)
  } else { Write-Output '未安装' }
  return
}
$j=Verify-Manifest $source
New-Item -ItemType Directory -Force -Path $base | Out-Null
if(Test-Path -LiteralPath $target){
  New-Item -ItemType Directory -Force -Path $backupBase | Out-Null
  $dst=Join-Path $backupBase ($skillFolder+'-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
  Move-Item -LiteralPath $target -Destination $dst
  Write-Output ('已备份旧版到 '+$dst)
}
Copy-Item -LiteralPath $source -Destination $target -Recurse
Verify-Manifest $target | Out-Null
Write-Output ('安装完成: '+$target+'  version '+$j.version)
Write-Output '在 Codex 新任务里说「用 cumcm-code-reviewer 评价这份代码」即可。'