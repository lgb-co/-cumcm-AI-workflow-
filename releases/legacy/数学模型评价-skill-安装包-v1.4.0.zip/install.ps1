﻿[CmdletBinding()]
param(
 [ValidateSet('Install','Check','Rollback','Uninstall')][string]$Action='Install',
 [string]$Destination=$(if(Test-Path (Join-Path $env:USERPROFILE '.codex\skills')){Join-Path $env:USERPROFILE '.codex\skills'}else{Join-Path $env:USERPROFILE '.agents\skills'}),
 [switch]$InstallDependencies,
 [switch]$MigrateLegacy
)
$ErrorActionPreference='Stop'
$skillId='cumcm-model-review'
$skillFolder='数学模型评价'
$source=Join-Path $PSScriptRoot $skillFolder
$base=[IO.Path]::GetFullPath($Destination)
$target=[IO.Path]::GetFullPath((Join-Path $base $skillFolder))
$backupBase=Join-Path ([IO.Directory]::GetParent($base).FullName) '.cumcm-model-review-backups'
function Assert-Target([string]$Path) {
 $resolved=[IO.Path]::GetFullPath($Path)
 if($resolved -ne $target -or [IO.Path]::GetFileName($resolved) -ne $skillFolder) {throw 'Refusing to modify an unexpected target.'}
 if((Test-Path -LiteralPath $resolved) -and ((Get-Item -LiteralPath $resolved).Attributes -band [IO.FileAttributes]::ReparsePoint)) {throw 'Refusing to modify a linked installation.'}
}
function Get-FileHash([string]$LiteralPath,[string]$Algorithm='SHA256') {
 $stream=[IO.File]::OpenRead($LiteralPath)
 $sha=[Security.Cryptography.SHA256]::Create()
 try {return @{Hash=([BitConverter]::ToString($sha.ComputeHash($stream))).Replace('-','')}} finally {$stream.Dispose();$sha.Dispose()}
}
function Verify-Package([string]$Folder) {
  if((Get-Item -LiteralPath $Folder).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Linked package is not supported.'}
 foreach($item in (Get-ChildItem -LiteralPath $Folder -Recurse -Force)) {if($item.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Package contains a linked item.'}}
 $manifestPath=Join-Path $Folder 'manifest.json'
 if(!(Test-Path -LiteralPath $manifestPath)){throw 'Package manifest is missing.'}
 $manifest=Get-Content -LiteralPath $manifestPath -Raw -Encoding UTF8 | ConvertFrom-Json
  if($manifest.name -ne $skillId -or $manifest.display_name -ne $skillFolder -or !$manifest.version -or @($manifest.files).Count -eq 0){throw 'Invalid package manifest.'}
 $listed=@{}
 foreach($entry in $manifest.files){
  if(!$entry.path -or $entry.sha256 -notmatch '^[a-fA-F0-9]{64}$' -or $listed.ContainsKey($entry.path)){throw 'Invalid or duplicate manifest entry.'}
  $listed[$entry.path]=$true
 }
 foreach($required in @('SKILL.md','run.ps1','scripts/review.py')){if(!$listed.ContainsKey($required)){throw ('Required file missing from manifest: '+$required)}}
 foreach($file in $manifest.files) {
  $path=[IO.Path]::GetFullPath((Join-Path $Folder $file.path))
  if(!$path.StartsWith(([IO.Path]::GetFullPath($Folder)+[IO.Path]::DirectorySeparatorChar),[StringComparison]::OrdinalIgnoreCase)){throw 'Unsafe manifest path.'}
  if(!(Test-Path -LiteralPath $path) -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower() -ne $file.sha256){throw ('Checksum mismatch: '+$file.path)}
 }
 return $manifest
}
$sourceFull=[IO.Path]::GetFullPath($source).TrimEnd('\')
if($target.TrimEnd('\') -eq $sourceFull -or $target.StartsWith($sourceFull+'\',[StringComparison]::OrdinalIgnoreCase) -or $sourceFull.StartsWith($target.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Destination must not overlap the source package.'}
if((Test-Path -LiteralPath $backupBase) -and ((Get-Item -LiteralPath $backupBase).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Linked backup directory is not supported.'}
$ancestor=$base
while($ancestor) {
 if((Test-Path -LiteralPath $ancestor) -and ((Get-Item -LiteralPath $ancestor).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Linked destination ancestors are not supported.'}
 $parent=[IO.Directory]::GetParent($ancestor); if(!$parent){break}; $ancestor=$parent.FullName
}
Assert-Target $target
if($Action -eq 'Check') {
 $manifest=Verify-Package $target
 Write-Output ('Verified '+$target+' version '+$manifest.version)
 return
}
if($Action -eq 'Uninstall') {
 if(Test-Path -LiteralPath $target) {
  $null=Verify-Package $target
  [IO.Directory]::CreateDirectory($backupBase)|Out-Null
  $backup=Join-Path $backupBase ('uninstalled-'+[DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss-fff'))
  Move-Item -LiteralPath $target -Destination $backup
  @{path=$backup;target=$target}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $backupBase 'last-backup.json') -Encoding UTF8
  Write-Output ('Installation moved to backup: '+$backup)
 }
 return
}
if($Action -eq 'Rollback') {
 $statePath=Join-Path $backupBase 'last-backup.json'
 if(!(Test-Path -LiteralPath $statePath)){throw 'No previous installation is available.'}
 $state=Get-Content -LiteralPath $statePath -Raw -Encoding UTF8|ConvertFrom-Json
 $previous=[IO.Path]::GetFullPath($state.path)
 if(!$previous.StartsWith(([IO.Path]::GetFullPath($backupBase)+[IO.Path]::DirectorySeparatorChar),[StringComparison]::OrdinalIgnoreCase)){throw 'Invalid backup path.'}
 if($state.target -ne $target){throw 'Backup belongs to another destination.'}
 if(!(Test-Path -LiteralPath (Join-Path $previous 'SKILL.md'))){throw 'Backup is unavailable.'}
 if((Get-Item -LiteralPath $previous).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Linked backup is not supported.'}
 $null=Verify-Package $previous
 if(Test-Path -LiteralPath $target){Move-Item -LiteralPath $target -Destination (Join-Path $backupBase ('rollback-replaced-'+[DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss-fff')))}
 Move-Item -LiteralPath $previous -Destination $target
 Write-Output ('Restored '+$target)
 return
}
$manifest=Verify-Package $source
[IO.Directory]::CreateDirectory($base)|Out-Null
if(Test-Path -LiteralPath $target) {
 $same=$false
 try {
  $old=Verify-Package $target
  $same=((Get-FileHash -LiteralPath (Join-Path $target 'manifest.json')).Hash -eq (Get-FileHash -LiteralPath (Join-Path $source 'manifest.json')).Hash)
 } catch {Write-Output 'Existing installation differs; it will be backed up.'}
 if($same) {Write-Output 'This version is already installed.'}
 else {
  [IO.Directory]::CreateDirectory($backupBase)|Out-Null
  $backup=Join-Path $backupBase ('previous-'+[DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss-fff'))
  Move-Item -LiteralPath $target -Destination $backup
  @{path=$backup;target=$target}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $backupBase 'last-backup.json') -Encoding UTF8
 }
}
if(!(Test-Path -LiteralPath $target)) {Copy-Item -LiteralPath $source -Destination $target -Recurse}
$null=Verify-Package $target
$legacyRoots=@((Join-Path $env:USERPROFILE '.codex\skills'),$base)
if($env:CODEX_HOME){$legacyRoots+=Join-Path $env:CODEX_HOME 'skills'}
foreach($legacyRoot in ($legacyRoots|Select-Object -Unique)) {
 foreach($legacyName in @('cumcm-model-review','数学建模评价')) {
  $legacy=Join-Path $legacyRoot $legacyName
  if($legacy -ne $target -and (Test-Path -LiteralPath (Join-Path $legacy 'SKILL.md'))) {
  if($MigrateLegacy) {
   [IO.Directory]::CreateDirectory($backupBase)|Out-Null
   $legacyBackup=Join-Path $backupBase ('legacy-'+[DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss-fff'))
   Move-Item -LiteralPath $legacy -Destination $legacyBackup
   @{original=$legacy;backup=$legacyBackup}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $backupBase 'legacy-migration.json') -Encoding UTF8
   Write-Output ('Legacy skill backed up to '+$legacyBackup)
  } else {Write-Output ('Legacy skill detected: '+$legacy+'. Use -MigrateLegacy to move it out of skill discovery; the new skill has a distinct identifier.')}
  }
 }
}
Write-Output ('Installed '+$target)
& (Join-Path $target 'run.ps1') environment
if($InstallDependencies) {& (Join-Path $target 'setup-dependencies.ps1')}
Write-Output 'Open a new Codex task and invoke 数学模型评价 or $cumcm-model-review. If it does not appear, restart Codex.'
